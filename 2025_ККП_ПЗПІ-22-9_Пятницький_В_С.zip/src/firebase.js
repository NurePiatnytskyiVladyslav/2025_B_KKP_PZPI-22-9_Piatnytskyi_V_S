import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyARYHBOPl4tl2emmrOiTasF4Xksr0F4sFI",
  authDomain: "quizpartyhub-598bf.firebaseapp.com",
  projectId: "quizpartyhub-598bf",
  storageBucket: "quizpartyhub-598bf.firebasestorage.app",
  messagingSenderId: "944517172910",
  appId: "1:944517172910:web:4618e2e63686f7f57b273f",
  measurementId: "G-RBXJ0BLKBR",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();
const db = getFirestore(app);

export { auth, provider, db };
