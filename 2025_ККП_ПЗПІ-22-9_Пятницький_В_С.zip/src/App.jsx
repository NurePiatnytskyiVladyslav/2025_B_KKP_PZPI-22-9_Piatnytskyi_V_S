import { useState } from "react";
import "./App.css";
import Header from "./components/Header.jsx";
import MainP_first from "./components/mp1_startcard.jsx";
import MainP_second from "./components/mp2_about.jsx";
import MainP_third from "./components/mp3_leaderboard";
import MainP_fourth from "./components/mp4_feedback.jsx";
import Footer from "./components/Footer.jsx";
import Quiz from "./components/Quiz.jsx";
import TestPanel from "./components/TestPanel.jsx"; // Імпорт панелі тестування

function App() {
  const [started, setStarted] = useState(false); // Стан запуску квізу

  return (
    <>
      <Header setStarted={setStarted} />
      {started ? (
        <div id="quiz">
          <Quiz />
        </div>
      ) : (
        <>
          <div id="home">
            <MainP_first onStart={() => setStarted(true)} />
          </div>

          <div id="quiz">
            <MainP_second />
          </div>

          <div id="leaders">
            <MainP_third />
          </div>

          <div id="about">
            <MainP_fourth />
          </div>
        </>
      )}

      <div id="contacts">
        <Footer />
      </div>
    </>
  );
}
export default App;
