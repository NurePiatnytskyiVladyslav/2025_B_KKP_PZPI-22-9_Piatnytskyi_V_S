import { useState } from "react";
import axios from "axios";
import { getAuth } from "firebase/auth";
import panda from "../assets/redpanda.png"; // твоя картинка пандочки

function Quiz() {
  const [topic, setTopic] = useState("");
  const [questions, setQuestions] = useState([]);
  const [current, setCurrent] = useState(0);
  const [loading, setLoading] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [selected, setSelected] = useState(null);
  const [isCorrect, setIsCorrect] = useState(null);

  const handleGenerateQuiz = async () => {
    if (!topic) return alert("Введіть тему!");

    try {
      setLoading(true);
      const auth = getAuth();
      const token = await auth.currentUser.getIdToken();

      const res = await axios.post(
        "http://localhost:5000/api/generate-quiz",
        { topic, questionsCount: 10 },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      // 🔽 Додаємо логування
      console.log("🎯 Обрана тема:", topic);
      console.log("📋 Згенерований квіз:", res.data.questions);

      setQuestions(res.data.questions);
      setCurrent(0);
      setSelected(null);
      setIsCorrect(null);
      setShowResult(false);
    } catch (error) {
      console.error("Помилка:", error);
      alert("Не вдалося згенерувати квіз.");
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = async (answer) => {
    if (selected !== null) return;

    const correctAnswer = questions[current].correctAnswer;
    const isRight = answer === correctAnswer;

    setSelected(answer);
    setIsCorrect(isRight);

    if (isRight) {
      try {
        const auth = getAuth();
        const token = await auth.currentUser.getIdToken();

        await axios.post(
          "http://localhost:5000/api/update-score",
          { score: 1 },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
      } catch (error) {
        console.error("❌ Не вдалося оновити очки:", error);
      }
    }
  };

  const nextQuestion = () => {
    if (current + 1 < questions.length) {
      setCurrent(current + 1);
      setSelected(null);
      setIsCorrect(null);
    } else {
      setShowResult(true);
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#fff7e9] flex flex-col items-center justify-start p-6">
      <div className="w-full max-w-3xl bg-white p-6 rounded-xl shadow mb-6 text-center">
        <h2 className="text-xl font-bold mb-2">Як грати?</h2>
        <p className="text-gray-600 text-base">
          Напиши тему, в якій ти добре розбираєшся, і ми створимо для тебе
          унікальний квіз. Це може бути <strong>фізика</strong>,{" "}
          <strong>аніме</strong>, <strong>Гаррі Поттер</strong>,{" "}
          <strong>Київ</strong> або навіть <strong>шкільні меми</strong>.
        </p>
      </div>

      {/* Тема */}
      <div className="w-full max-w-3xl mb-6 flex items-center space-x-4">
        <input
          type="text"
          placeholder="Введіть тему"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          className="flex-grow rounded-full px-6 py-3 text-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 bg-white"
        />
        <button
          onClick={handleGenerateQuiz}
          disabled={loading}
          className="bg-sky-500 hover:bg-sky-700 text-white px-6 py-3 rounded-full text-lg"
        >
          {loading ? "Генерується..." : "Згенерувати"}
        </button>
      </div>

      {questions.length == 0 && !showResult && (
        <div className="w-full flex justify-center my-4">
          <img
            src={panda}
            alt="Пандочка перед грою"
            className="w-full max-w-md rounded-xl"
          />
        </div>
      )}

      {/* Квіз */}
      {questions.length > 0 && !showResult && (
        <div className="w-full max-w-3xl bg-[#fef6e4] p-6 rounded-xl shadow-lg flex flex-col items-center space-y-6">
          {/* Питання */}
          <div className="text-2xl font-semibold text-center bg-white px-6 py-4 rounded-full w-full">
            {questions[current].question}
          </div>

          {/* Варіанти */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
            {questions[current].answers.map((opt, idx) => {
              const isCorrectAnswer = opt === questions[current].correctAnswer;
              const isSelected = selected === opt;

              const baseStyle =
                "w-full py-6 rounded-2xl text-white text-lg font-semibold cursor-pointer text-center transition";
              let color = "";

              if (selected) {
                if (isCorrectAnswer) color = "bg-green-600";
                else if (isSelected) color = "bg-red-600";
                else color = "bg-gray-300 text-gray-700";
              } else {
                const colors = [
                  "bg-red-500",
                  "bg-blue-500",
                  "bg-yellow-400",
                  "bg-green-500",
                ];
                color = colors[idx % colors.length];
              }

              return (
                <div
                  key={idx}
                  className={`${baseStyle} ${color}`}
                  onClick={() => handleAnswer(opt)}
                >
                  {opt}
                </div>
              );
            })}
          </div>

          {/* Повідомлення + кнопка */}
          {selected && (
            <div className="text-center">
              <p
                className={`text-xl font-bold ${
                  isCorrect ? "text-green-600" : "text-red-600"
                }`}
              >
                {isCorrect ? "✅ Правильно!" : "❌ Неправильно"}
              </p>
              <button
                onClick={nextQuestion}
                className="mt-4 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-full"
              >
                Наступне питання
              </button>
            </div>
          )}
        </div>
      )}

      {/* Завершення */}
      {showResult && (
        <div className="w-full max-w-2xl bg-white p-6 mt-6 rounded-xl shadow text-center">
          <p className="text-2xl font-bold mb-4">Квіз завершено ✅</p>
          <button
            onClick={() => {
              setQuestions([]);
              setTopic("");
              setCurrent(0);
              setShowResult(false);
            }}
            className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-full"
          >
            Почати спочатку
          </button>
        </div>
      )}
    </div>
  );
}

export default Quiz;
