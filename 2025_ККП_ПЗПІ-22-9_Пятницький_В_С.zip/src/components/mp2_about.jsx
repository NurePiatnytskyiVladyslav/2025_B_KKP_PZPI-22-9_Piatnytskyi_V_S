import img1 from "../assets/img1_music.svg";
import img2 from "../assets/img2_gamepad.svg";
import img3 from "../assets/img3_film.svg";
import img4 from "../assets/img4_sticker.svg";

function MainP_second() {
  return (
    <div
      className="w-full flex flex-col pb-10"
      style={{ backgroundColor: "rgba(247, 237, 217, 1)" }}
    >
      {/* 1st block */}
      <div className="flex flex-col items-center w-full">
        <div className="pt-5 text-2xl">Обери свою тему для гри</div>
        <div className="flex flex-row justify-center items-center space-x-10 py-10">
          <div className="flex flex-col items-center">
            <div
              className="block w-30 h-30 bg-slate-200 rounded-full flex items-center justify-center"
              style={{ backgroundColor: "rgba(86, 184, 97, 1)" }}
            >
              <img src={img1} alt="img1" className="w-20 h-auto" />
            </div>
            <div>Музика</div>
          </div>
          <div className="flex flex-col items-center">
            <div
              className="block w-30 h-30 bg-slate-200 rounded-full flex items-center justify-center"
              style={{ backgroundColor: "rgba(0, 149, 213, 1)" }}
            >
              <img src={img2} alt="img2" className="w-20 h-auto" />
            </div>
            <div>Ігри</div>
          </div>
          <div className="flex flex-col items-center">
            <div
              className="block w-30 h-30 bg-slate-200 rounded-full flex items-center justify-center"
              style={{ backgroundColor: "rgba(248, 48, 69, 1)" }}
            >
              <img src={img3} alt="img3" className="w-20 h-auto" />
            </div>
            <div>Фільми</div>
          </div>
          <div className="flex flex-col items-center">
            <div
              className="block w-30 h-30 bg-slate-200 rounded-full flex items-center justify-center"
              style={{ backgroundColor: "rgba(163, 188, 192, 1)" }}
            >
              <img src={img4} alt="img4" className="w-25 h-auto" />
            </div>
            <div>Меми</div>
          </div>
        </div>
      </div>

      {/* 2nd block */}
      <div className="flex flex-row justify-around pr-60 pl-60">
        <div className="flex flex-col items-center">
          <div className="py-5">Про гру</div>
          <div className="block w-70 min-h-90 bg-white rounded-2xl p-3 text-sm space-y-2">
            <p>
              <strong>Quiz Party Hub</strong> — це гра для тих, хто хоче
              випробувати свої знання та розважитися одночасно. Тут ти сам
              обираєш тему, і ми створюємо для тебе унікальний квіз із 10
              запитань.
            </p>
            <p>
              Кожна відповідь — це шанс набрати очки, піднятись у топ гравців і
              показати всім, хто тут розумник! 😉
            </p>
            <p>
              Ідеально підходить для вечірок, перерв між навчанням або просто
              щоб перевірити себе.
            </p>
          </div>
        </div>
        <div className="flex flex-col items-center">
          <div className="py-5">Особливості</div>
          <div className="block w-70 min-h-90 bg-white rounded-2xl p-3 text-sm space-y-2">
            <p>
              <strong>🔥 Унікальні теми:</strong> обирай будь-що — від Гаррі
              Поттера до мемів про школу. Кожен квіз — персоналізований!
            </p>
            <p>
              <strong>📈 Рейтинг гравців:</strong> відповідай правильно та
              змагайся за місце в таблиці лідерів.
            </p>
            <p>
              <strong>🎨 Яскравий дизайн:</strong> зручний інтерфейс,
              адаптований для всіх пристроїв.
            </p>
            <p>
              <strong>👥 Google-авторизація:</strong> увійшов — і одразу в грі.
              Жодних форм і реєстрацій.
            </p>
            <p>
              <strong>💬 Відгуки гравців:</strong> залишай свої враження, читай
              думки інших прямо на сайті!
            </p>
          </div>
        </div>
        <div className="flex flex-col items-center">
          <div className="py-5">Як грати</div>
          <div className="block w-70 min-h-90 bg-white rounded-2xl p-3 text-sm space-y-2">
            <p>
              <strong>1.</strong> Натисни "Розпочати" та увійди через Google.
              Все швидко й просто.
            </p>
            <p>
              <strong>2.</strong> Введи тему, яка тобі цікава — ми згенеруємо
              для тебе 10 запитань.
            </p>
            <p>
              <strong>3.</strong> Відповідай на питання. Не поспішай, але й не
              зволікай!
            </p>
            <p>
              <strong>4.</strong> Кожна правильна відповідь = очки. А очки — це
              шлях до вершини рейтингу.
            </p>
            <p>
              <strong>5.</strong> Завершив? Поділись результатом з друзями та
              починай новий квіз!
            </p>
          </div>
        </div>
      </div>

      {/* 3rd block */}
      <div className="flex items-center justify-between w-full max-w-4xl mx-auto pt-20">
        {/* Блок 1 */}
        <div className="flex flex-col items-center">
          <div className="w-6 h-6 bg-orange-400 rounded-full"></div>
          <div className="mt-2 font-semibold">Розпочни</div>
        </div>

        {/* Лінія */}
        <div className="flex-1 border-t-6 border-dashed border-gray-700 mx-2 "></div>

        {/* Блок 2 */}
        <div className="flex flex-col items-center">
          <div className="w-6 h-6 bg-red-400 rounded-full"></div>
          <div className="mt-2 font-semibold">Клич друзів</div>
        </div>

        {/* Лінія */}
        <div className="flex-1 border-t-6 border-dashed border-gray-700 mx-2"></div>

        {/* Блок 3 */}
        <div className="flex flex-col items-center">
          <div className="w-6 h-6 bg-green-400 rounded-full"></div>
          <div className="mt-2 font-semibold">Обирай тему</div>
        </div>

        {/* Лінія */}
        <div className="flex-1 border-t-6 border-dashed border-gray-700 mx-2"></div>

        {/* Блок 4 */}
        <div className="flex flex-col items-center">
          <div className="w-6 h-6 bg-blue-400 rounded-full"></div>
          <div className="mt-2 font-semibold">Грай</div>
        </div>
      </div>
    </div>
  );
}

export default MainP_second;
