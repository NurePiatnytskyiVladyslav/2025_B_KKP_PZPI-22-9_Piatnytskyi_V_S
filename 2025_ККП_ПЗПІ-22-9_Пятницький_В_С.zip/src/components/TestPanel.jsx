// TestPanel.jsx
import { useState } from "react";
import axios from "axios";
import { getAuth } from "firebase/auth";

export default function TestPanel() {
  const [token, setToken] = useState("");
  const [log, setLog] = useState("");

  const logMessage = (message, data = null) => {
    setLog(message + (data ? "\n" + JSON.stringify(data, null, 2) : ""));
    console.log("📋 " + message);
    if (data) console.log(data);
  };

  const getToken = async () => {
    const auth = getAuth();
    const user = auth.currentUser;
    if (user) {
      const idToken = await user.getIdToken();
      setToken(idToken);
      logMessage("✅ Token отримано", { token: idToken.slice(0, 30) + "..." });
    } else {
      logMessage("❌ Користувач не авторизований");
    }
  };

  const testGenerateQuiz = async () => {
    try {
      const res = await axios.post(
        "/api/generate-quiz",
        { topic: "Історія України", questionsCount: 5 },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      logMessage("✅ Квіз згенеровано", res.data.questions[0]);
    } catch (err) {
      logMessage("❌ Помилка генерації квізу", { error: err.message });
    }
  };

  const testProfile = async () => {
    try {
      const res = await axios.get("/api/my-profile", {
        headers: { Authorization: `Bearer ${token}` },
      });
      logMessage("✅ Профіль користувача", res.data);
    } catch (err) {
      logMessage("❌ Помилка завантаження профілю", { error: err.message });
    }
  };

  const testLeaderboard = async () => {
    try {
      const res = await axios.get("/api/leaderboard");
      logMessage("🏆 Лідери", res.data);
    } catch (err) {
      logMessage("❌ Помилка завантаження лідерборду", { error: err.message });
    }
  };

  return (
    <div className="p-4 bg-gray-100 rounded-lg max-w-xl mx-auto mt-8">
      <h2 className="font-bold text-lg mb-3">🔧 Панель тестування API</h2>
      <button onClick={getToken} className="btn">
        1. Отримати токен
      </button>
      <button onClick={testGenerateQuiz} className="btn mt-2">
        2. Згенерувати квіз
      </button>
      <button onClick={testProfile} className="btn mt-2">
        3. Завантажити профіль
      </button>
      <button onClick={testLeaderboard} className="btn mt-2">
        4. Завантажити лідерборд
      </button>

      <pre className="mt-4 bg-white p-3 text-sm overflow-x-auto border rounded">
        {log}
      </pre>
    </div>
  );
}
