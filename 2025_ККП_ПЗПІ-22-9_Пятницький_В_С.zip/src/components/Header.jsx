import { useEffect, useState } from "react";
import {
  getAuth,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  GoogleAuthProvider,
} from "firebase/auth";
import { doc, onSnapshot, setDoc } from "firebase/firestore";
import { auth, provider, db } from "../firebase";
import defaultAvatar from "../assets/Main_Logo.svg";
import lillogo from "../assets/LittleMain_Logo.svg";

function Header({ setStarted }) {
  const [user, setUser] = useState(null);
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        const userRef = doc(db, "users", currentUser.uid);

        const unsubscribeSnapshot = onSnapshot(userRef, (docSnap) => {
          if (docSnap.exists()) {
            setUserData(docSnap.data());
          } else {
            const defaultData = {
              uid: currentUser.uid,
              email: currentUser.email,
              displayName: currentUser.displayName || "Без імені",
              avatarUrl: currentUser.photoURL || "",
              score: 0,
              level: "Новачок",
            };
            setDoc(userRef, defaultData);
            setUserData(defaultData);
          }
        });

        return () => unsubscribeSnapshot();
      } else {
        setUser(null);
        setUserData(null);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  const handleLogin = async () => {
    const auth = getAuth();
    const provider = new GoogleAuthProvider();

    try {
      const result = await signInWithPopup(auth, provider); // ✅ лише один виклик!
      const user = result.user;
      const token = await user.getIdToken();

      console.log("✅ Успішна авторизація");
      console.log("👤 Користувач:", user.displayName);
      console.log("📧 Email:", user.email);
      console.log("🔑 Токен:", token.slice(0, 30) + "...");
    } catch (error) {
      console.error("❌ Помилка авторизації:", error.message);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  // console.log("asdasd");

  return (
    <header className="w-full bg-white shadow-md px-6 py-3 flex items-center justify-between relative sticky top-0 z-50">
      {/* Logo */}
      <div className="flex items-center space-x-2">
        <img src={lillogo} alt="Логотип" className="w-10 h-10" />
      </div>

      {/* Навігація */}
      <nav className="hidden md:flex space-x-6 text-gray-700 text-sm font-medium absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        <a
          href="#home"
          onClick={() => setStarted(false)}
          className="hover:text-sky-500 transition"
        >
          Головна
        </a>
        <a href="#quiz" className="hover:text-sky-500 transition">
          Квіз
        </a>
        <a href="#leaders" className="hover:text-sky-500 transition">
          Лідери
        </a>
        <a href="#about" className="hover:text-sky-500 transition">
          Про нас
        </a>
        <a href="#contacts" className="hover:text-sky-500 transition">
          Контакти
        </a>
      </nav>

      {/* Акаунт / Вхід */}
      <div className="flex items-center space-x-4">
        {user && userData ? (
          <>
            <img
              src={userData.avatarUrl || defaultAvatar}
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = defaultAvatar;
              }}
              alt="avatar"
              className="w-10 h-10 rounded-full object-cover border-2 border-sky-500"
            />
            <div className="text-sm leading-tight text-right">
              <p className="font-semibold text-gray-800 truncate max-w-[120px]">
                {userData.displayName}
              </p>
              <p className="text-xs text-gray-500">Очки: {userData.score}</p>
            </div>
            <button
              onClick={handleLogout}
              className="bg-red-500 hover:bg-red-600 text-white px-4 py-1.5 rounded-full text-sm"
            >
              Вийти
            </button>
          </>
        ) : (
          <button
            onClick={handleLogin}
            className="bg-sky-500 hover:bg-sky-600 text-white px-6 py-2 rounded-full text-sm font-medium"
          >
            Увійти
          </button>
        )}
      </div>
    </header>
  );
}

export default Header;
