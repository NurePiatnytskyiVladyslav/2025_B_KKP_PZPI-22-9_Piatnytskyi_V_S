import {
  FaInstagram,
  FaDiscord,
  FaTelegram,
  FaEnvelope,
  FaTwitter,
} from "react-icons/fa"; // fallback Twitter
// Якщо у тебе оновлений react-icons, можеш замінити FaTwitter на FaXTwitter з "react-icons/fa6"

function MainP_fourth() {
  const reviews = [
    { text: "Крута гра! Дуже затягує 🔥" },
    { text: "Мені подобається система лідерів!" },
    { text: "Дизайн просто вау. Чекаю нових тем!" },
  ];

  return (
    <div className="bg-[#F7EDD9] py-10 px-4 flex flex-col items-center rounded-xl">
      <h2 className="text-2xl font-semibold mb-6">Відгуки гравців</h2>

      {/* Слайдер з відгуками */}
      <div className="flex items-center space-x-4 mb-10">
        <button className="text-2xl text-gray-400">{"‹"}</button>

        <div className="flex space-x-4 overflow-x-auto">
          {reviews.map((review, i) => (
            <div
              key={i}
              className="bg-white w-60 h-60 rounded-xl shadow p-4 flex flex-col items-center justify-center text-center"
            >
              <div className="w-10 h-10 bg-gray-300 rounded-full mb-4" />
              <div className="text-sm text-gray-700 italic">
                “{review.text}”
              </div>
            </div>
          ))}
        </div>

        <button className="text-2xl text-gray-400">{"›"}</button>
      </div>

      {/* Соцмережі */}
      <div className="text-lg font-semibold mb-3">
        Поділись своїми враженнями
      </div>
      <div className="flex space-x-4">
        <a
          href="https://twitter.com"
          target="_blank"
          rel="noreferrer"
          className="bg-violet-400 p-2 rounded-xl hover:scale-105 transition"
        >
          <FaTwitter className="text-black text-xl" />
        </a>
        <a
          href="https://instagram.com"
          target="_blank"
          rel="noreferrer"
          className="bg-rose-400 p-2 rounded-xl hover:scale-105 transition"
        >
          <FaInstagram className="text-black text-xl" />
        </a>
        <a
          href="https://discord.com"
          target="_blank"
          rel="noreferrer"
          className="bg-green-400 p-2 rounded-xl hover:scale-105 transition"
        >
          <FaDiscord className="text-black text-xl" />
        </a>
        <a
          href="https://t.me"
          target="_blank"
          rel="noreferrer"
          className="bg-orange-400 p-2 rounded-xl hover:scale-105 transition"
        >
          <FaTelegram className="text-black text-xl" />
        </a>
        <a
          href="mailto:example@email.com"
          className="bg-sky-400 p-2 rounded-xl hover:scale-105 transition"
        >
          <FaEnvelope className="text-black text-xl" />
        </a>
      </div>
    </div>
  );
}

export default MainP_fourth;
