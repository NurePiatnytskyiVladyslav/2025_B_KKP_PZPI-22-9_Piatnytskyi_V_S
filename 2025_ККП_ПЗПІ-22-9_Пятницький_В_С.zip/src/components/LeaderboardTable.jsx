import { useEffect, useState } from "react";
import axios from "axios";
import { getAuth } from "firebase/auth";
import defaultAvatar from "../assets/img_person.svg";

function LeaderboardTable() {
  const [leaders, setLeaders] = useState([]);

  useEffect(() => {
    const auth = getAuth();
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (!user) return;

      try {
        const token = await user.getIdToken();
        const res = await axios.get("http://localhost:5000/api/leaderboard", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setLeaders(res.data.leaderboard || []);
      } catch (error) {
        console.error("❌ Помилка при завантаженні лідерборду:", error);
      }
    });

    return () => unsubscribe();
  }, []);

  console.log("Лідери:", leaders);

  return (
    <tbody>
      {leaders.map((user, idx) => (
        <tr key={idx} className="bg-white shadow rounded">
          <td className="px-4 py-2 font-semibold">{idx + 1}</td>
          <td className="px-4 py-2 flex items-center space-x-2">
            <img
              src={user.avatarUrl || defaultAvatar}
              alt="avatar"
              className="w-6 h-6 rounded-full border"
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = defaultAvatar;
              }}
            />
            <span>{user.displayName}</span>
          </td>
          <td className="px-4 py-2 font-semibold text-blue-600">
            {user.score}
          </td>
        </tr>
      ))}
    </tbody>
  );
}

export default LeaderboardTable;
