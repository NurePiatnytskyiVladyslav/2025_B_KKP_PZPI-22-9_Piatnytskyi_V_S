import LeaderboardTable from "./LeaderboardTable.jsx";
import img5 from "../assets/img5_cup.svg"; // Підключення зображення кубка

function MainP_third() {
  return (
    <div className="w-full flex flex-col items-center py-8 bg-white rounded-lg shadow">
      {/* Заголовок з кубком */}
      <div className="flex items-center space-x-4 mb-4">
        <div className="w-16 h-16 bg-blue-400 p-3 rounded-full flex items-center justify-center">
          <img src={img5} alt="Кубок" className="w-10 h-auto" />
        </div>
        <div className="text-2xl font-semibold">Таблиця лідерів</div>
      </div>

      {/* Підзаголовок */}
      <div className="text-gray-600 mb-4">
        Відповідай правильно, щоб піднятись в топі!
      </div>

      {/* Таблиця */}
      <div className="w-full max-w-3xl pb-4">
        <table className="w-full table-auto border-separate border-spacing-y-2">
          <thead>
            <tr className="bg-gray-200 text-left">
              <th className="px-4 py-2 rounded-l-md">Місце</th>
              <th className="px-4 py-2">Нікнейм</th>
              <th className="px-4 py-2 rounded-r-md">Очки</th>
            </tr>
          </thead>
          <LeaderboardTable />
        </table>
      </div>
    </div>
  );
}

export default MainP_third;
