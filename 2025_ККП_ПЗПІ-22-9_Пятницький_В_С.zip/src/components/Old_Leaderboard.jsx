import { useEffect, useState } from "react";
import axios from "axios";
import { getAuth, onAuthStateChanged } from "firebase/auth";
import defaultAvatar from "../assets/img_person.svg";

function Leaderboard() {
  const [leaders, setLeaders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const auth = getAuth();

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        console.warn("❗ Користувач не авторизований.");
        setLoading(false);
        return;
      }

      try {
        const token = await user.getIdToken();

        const res = await axios.get("http://localhost:5000/api/leaderboard", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        setLeaders(res.data.leaderboard || []);
      } catch (error) {
        console.error("❌ Помилка при завантаженні лідерборду:", error);
      } finally {
        setLoading(false);
      }
    });

    return () => unsubscribe(); // При демонтажі компонента
  }, []);

  return (
    <div className="p-4 w-full max-w-2xl">
      <h2 className="text-xl font-bold mb-4">🏆 Топ-10 гравців</h2>
      {loading ? (
        <p>Завантаження...</p>
      ) : (
        <ul className="space-y-3">
          {leaders.map((user, index) => (
            <li
              key={index}
              className="flex items-center gap-4 p-2 border rounded bg-white shadow-sm"
            >
              <span className="text-gray-500 font-bold w-6">{index + 1}.</span>
              <img
                src={user.avatarUrl || defaultAvatar}
                onError={(e) => {
                  e.target.onerror = null;
                  e.target.src = defaultAvatar;
                }}
                alt="avatar"
                className="w-10 h-10 rounded-full border"
              />
              <div className="flex-grow">
                <p className="font-semibold">{user.displayName}</p>
                <p className="text-sm text-gray-500">Рівень: {user.level}</p>
              </div>
              <div className="text-right">
                <p className="text-blue-600 font-bold">{user.score} 🧠</p>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default Leaderboard;
