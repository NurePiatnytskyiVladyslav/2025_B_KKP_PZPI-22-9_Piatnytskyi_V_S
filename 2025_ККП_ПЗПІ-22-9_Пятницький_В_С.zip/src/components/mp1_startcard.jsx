import logo from "../assets/Main_Logo.svg"; // адаптуй шлях, якщо інший

function MainP_first({ onStart }) {
  return (
    <div
      className="w-full flex flex-col justify-center items-center p-10"
      style={{ backgroundColor: "rgba(255, 226, 81, 1)" }}
    >
      <div>
        <img src={logo} alt="Великий Логотип" className="w-60 h-auto" />
      </div>

      <div className="text-5xl font-bold text-center py-10">
        Спробуй себе у <br />
        Quiz Party Hub!
      </div>

      <button
        className="w-40 h-10 text-white bg-sky-500 hover:bg-sky-700 rounded-2xl"
        onClick={onStart}
      >
        Розпочати
      </button>
    </div>
  );
}

export default MainP_first;
