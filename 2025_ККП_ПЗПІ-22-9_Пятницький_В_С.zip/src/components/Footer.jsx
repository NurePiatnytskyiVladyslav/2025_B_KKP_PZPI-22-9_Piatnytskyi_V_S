import { FaInstagram, FaTelegram, FaDiscord, FaEnvelope } from "react-icons/fa";
import logo from "../assets/LittleMain_Logo.svg"; // адаптуй шлях

function Footer() {
  return (
    <footer className="py-8 px-8 mt-10">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-start gap-8">
        {/* Logo and brand */}
        <div className="flex flex-col items-start">
          <img src={logo} alt="Logo" className="w-12 mb-2" />
          <h3 className="text-lg font-bold">Quiz Party Hub</h3>
          <p className="text-sm text-gray-500">
            © {new Date().getFullYear()} Всі права захищені
          </p>
        </div>

        {/* Навігація */}
        <div className="flex flex-col space-y-2">
          <h4 className="font-semibold">Навігація</h4>
          <a href="#" className="hover:underline text-sm">
            Головна
          </a>
          <a href="#" className="hover:underline text-sm">
            Квіз
          </a>
          <a href="#" className="hover:underline text-sm">
            Таблиця лідерів
          </a>
          <a href="#" className="hover:underline text-sm">
            Про нас
          </a>
        </div>

        {/* Контакти */}
        <div className="flex flex-col space-y-2">
          <h4 className="font-semibold">Контакти</h4>
          <a
            href="mailto:quizparty@example.com"
            className="text-sm hover:underline"
          >
            quizparty@example.com
          </a>
          <a
            href="https://t.me/yourchannel"
            className="text-sm hover:underline"
          >
            Telegram
          </a>
        </div>

        {/* Соцмережі */}
        <div className="flex flex-col space-y-2">
          <h4 className="font-semibold">Ми в соцмережах</h4>
          <div className="flex space-x-3">
            <a href="https://instagram.com" target="_blank" rel="noreferrer">
              <FaInstagram className="text-xl hover:text-pink-600" />
            </a>
            <a href="https://discord.com" target="_blank" rel="noreferrer">
              <FaDiscord className="text-xl hover:text-indigo-600" />
            </a>
            <a href="https://t.me" target="_blank" rel="noreferrer">
              <FaTelegram className="text-xl hover:text-blue-500" />
            </a>
            <a href="mailto:quizparty@example.com">
              <FaEnvelope className="text-xl hover:text-sky-500" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
