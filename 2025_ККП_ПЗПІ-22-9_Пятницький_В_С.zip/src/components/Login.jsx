import { signInWithPopup, signOut } from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { auth, provider, db } from "../firebase";
import { useState, useEffect } from "react";
import { onAuthStateChanged } from "firebase/auth";

function Login() {
  const [user, setUser] = useState(null);
  const [userData, setUserData] = useState(null);

  console.log(user);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        const userRef = doc(db, "users", currentUser.uid);
        const userSnap = await getDoc(userRef);
        if (userSnap.exists()) {
          setUserData(userSnap.data());
        }
      } else {
        setUser(null);
        setUserData(null);
      }
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      const userRef = doc(db, "users", user.uid);
      const userSnap = await getDoc(userRef);

      if (!userSnap.exists()) {
        const defaultData = {
          uid: user.uid,
          displayName: user.displayName || "Новий Нікнейм",
          email: user.email,
          avatarUrl: user.photoURL,
          score: 0,
          level: "Новачок",
        };
        await setDoc(userRef, defaultData);
        setUserData(defaultData);
        console.log("🔥 Пользователь создан в Firestore");
      } else {
        setUserData(userSnap.data());
        console.log("✅ Пользователь найден в Firestore");
      }

      setUser(user);
    } catch (error) {
      console.error("Auth error:", error);
      alert("Помилка авторизації");
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setUser(null);
      setUserData(null);
    } catch (error) {
      console.error("Logout error:", error);
      alert("Помилка виходу");
    }
  };

  return (
    <div className="flex flex-col items-center gap-4 mt-8">
      {user && userData ? (
        <div className="flex flex-col items-center">
          <div className="flex items-center gap-4 mb-2">
            <img
              src={userData.avatarUrl}
              alt="User Avatar"
              className="w-12 h-12 rounded-full border-2 border-blue-500"
            />
            <div>
              <p className="text-lg font-semibold">{userData.displayName}</p>
              <p className="text-sm text-gray-500">{userData.email}</p>
            </div>
          </div>
          <p className="text-sm">
            Рівень: <strong>{userData.level}</strong>
          </p>
          <p className="text-sm">
            Очки: <strong>{userData.score}</strong>
          </p>

          <button
            className="mt-4 w-24 h-8 text-white bg-red-500 hover:bg-red-700 rounded text-sm"
            onClick={handleLogout}
          >
            Вийти
          </button>
        </div>
      ) : (
        <button
          className="w-40 h-10 text-white bg-blue-500 hover:bg-blue-700 rounded"
          onClick={signInWithGoogle}
        >
          Увійти через Google
        </button>
      )}
    </div>
  );
}

export default Login;
